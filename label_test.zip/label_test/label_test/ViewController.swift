//
//  ViewController.swift
//  label_test
//
//  Created by MAC on 28/05/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var lb1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
      //  lb1.text = "Hello World!, Whats Up ?"
     /*   UIView.animate(withDuration: 5) {
            self.lb1.center = self.view.center
        }*/
        
        let text = "Hello World, Whats Up ?"
        let change = "World"

        let range = (text as NSString).range(of: change)

        let attributedString = NSMutableAttributedString(string:text)
        attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.red , range: range)
        self.lb1.attributedText = attributedString
        
        
       /*let str = NSMutableAttributedString(string: "Hello World!, Whats Up ?")
        str.addAttributes([NSAttributedString.Key.foregroundColor: UIColor.red], range: NSMakeRange(6, 6))
        lb1.attributedText = str*/
        
      /*  let string = "Hello World!, Whats Up ?"
        let attributedString = NSMutableAttributedString.init(string: string)
        let range = (string as NSString).range(of: "world!")
        attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.blue, range: range)
        lb1.attributedText = attributedString*/
        
         /*  let attrs1 = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 18), NSAttributedString.Key.foregroundColor : UIColor.black]

           let attrs2 = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 18), NSAttributedString.Key.foregroundColor : UIColor.red]

           let attributedString1 = NSMutableAttributedString(string:"Hello", attributes:attrs1)

           let attributedString2 = NSMutableAttributedString(string:"World!", attributes:attrs2)

           attributedString1.append(attributedString2)
           self.lb1.attributedText = attributedString1*/
        
            lb1.font = .italicSystemFont(ofSize: 20)
            lb1.backgroundColor = UIColor.green
    
            //lb1.textColor = UIColor.red
            lb1.textAlignment = .center
            lb1.shadowColor = UIColor.black
            lb1.layer.borderWidth = 2.0
            lb1.layer.borderColor = UIColor.systemPink.cgColor
            lb1.isHighlighted = true
        
//        let nameLBL = UILabel()
//        nameLBL.frame = CGRect(x: <#T##CGFloat#>, y: <#T##CGFloat#>, width: <#T##CGFloat#>, height: <#T##CGFloat#>)
        
        let label = UILabel(frame: CGRect(x: 10, y: 200, width: self.view.frame.size.width-20, height: 200))
        //label.center = CGPoint(x: 150, y: 50)
        label.textAlignment = .left
        label.text = "Welcome to the Label"
        //label.numberOfLines = 0
        label.layer.borderWidth = 3.0
        label.font = .boldSystemFont(ofSize: 25)
        //label.sizeToFit()
        self.view.addSubview(label)
        
      /*  let label1 = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        label1.center = CGPoint(x: 200, y: 320)
        label1.textAlignment = .center
        label1.text = "Welcome to surat"
        label1.textColor = UIColor.purple
        label.shadowColor = UIColor.yellow
        self.view.addSubview(label1)*/
        
        let label2 = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 21))
        label2.center = CGPoint(x: 230, y: 600)
        label2.textAlignment = .center
        label2.text = "Welcome to Smart Technica"
        label2.font = .boldSystemFont(ofSize: 20)
        label2.textColor = UIColor.blue
        label2.isHighlighted = true
        self.view.addSubview(label2)
       
        // Do any additional setup after loading the view.
    }


}
